1. Securecrt
      * recover home_main.html
          *  ```
            cp -f umei_bak/view/public/room_main.html umei/view/public/room_main.html 
            ```
2. YUI Doc
      * inside of docs directory run 
        *   ```
            yuidocsite
            yuidocsite --port 3000 
            ```
        * go to site url in browser
            * http://localhost:3000 
3. Auth
      * 登录名 zhangsir     ID 32087834
        密码：1qa2ws