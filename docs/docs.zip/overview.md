1. Compatibility:
    * desktop browsers
        * ![Image of Browsers](docs/browser.png)
    