1. Online demo: 
    * [line chart](http://runjs.cn/code/qpf55aa2)
    * [卡后台-活动规则-价格规则](http://172.16.1.115/?m=cardactivity&a=default)
2. Local Demo: public/examples    
3. Account: 
   * xuehua  ab123456 超级管理员
4. SVN sync
   * cd /root/tongbu/bin/
   * vi filelist.txt 
   * add the files path as the following:
     * public/group/js/add-a-roll.js
     * application/modules/group/views/scripts/ticket-strategy/add-display.phtml
   * ./sendTest.sh 