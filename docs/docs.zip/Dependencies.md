1. Amcharts
    [Online Serial Chat](http://runjs.cn/code/qpf55aa2)
2. jquery
    * version: 2.1.3
    * plugins
        * jquery.validate
        * jquery.ui.datePicker, tooltip, dialog
        * multi-select 
            * based on a predefined variable
        * [chosen.jquery.js](http://harvesthq.github.io/chosen/)
            * Chosen, a Select Box Enhancer for jQuery and Prototype
        * [jQuery List DragSort](http://dragsort.codeplex.com/) not used
        * [jQuery Pagination](http://www.jquerypagination.com/)
        * [DATETIMEPICKER](http://jqueryplugin.net/datetimepicker-jquery-plugin-select-date-time/)
3. **refer to [卡后台](http://172.16.1.115/?m=yushouquanbook&a=default) ?**                
               